package main

import (
	"bufio"
	"fmt"
	"log"
	"os"
	"strings"
)

type BookCollection []Book

type Book struct {
	Title, Isbn, Authors, Description string
}

func main() {
	var bookStorage BookCollection

	books := readCSV("data/books.csv")
	// authors := readCSV("data/authors.csv")
	// magazines := readCSV("data/magazines.csv")



	for _, bookline := range books {
		bookValues := tokenize(bookline, ";")
		book := Book{
			Title:       bookValues[0],
			Isbn:        bookValues[1],
			Authors:     bookValues[2],
			Description: bookValues[3],
		}

		bookStorage = append(bookStorage, book)
	}

	

	in := bufio.NewScanner(os.Stdin)
	
	for {
		input := in.Text()
		if input == "" {
			continue
		}
		data := tokenize(input, " ")
		if len(data) > 0 {
			fmt.Println("received command : ", data)
		}
		
		switch {
			case data[0] == "exit":
				fmt.Println("exited program succesfully")
				os.Exit(0)
			case data[0] == "booklook":
				book, err := bookStorage.findBookByISBN(data[1])
				if err != nil {
					log.Println(err)
				} else {
					log.Printf("%+v \n", book)
				}
		}

	}

}

func readCSV(fileName string) []string {

	var result []string

	file, err := os.Open(fileName)
	if err != nil {
		log.Fatal(err)
	}
	defer file.Close()

	scanner := bufio.NewScanner(file)
	scanner.Scan() // to remove table header

	for scanner.Scan() {
		result = append(result, scanner.Text())
	}

	return result
}

func tokenize(line, token string) []string {
	return strings.Split(line, token)
}

func (bc BookCollection) findBookByISBN(isbn string) (*Book, error) {
	for _, book := range bc {
		if book.Isbn == isbn {
			return &book, nil
		}
	}

	return nil, fmt.Errorf("Book with ISBN %s not found", isbn)
}
